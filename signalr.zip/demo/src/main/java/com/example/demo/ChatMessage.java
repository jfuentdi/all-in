package com.example.demo;

/**
 * ChatMessage
 */
public class ChatMessage {
    public String sender;
    public String text;
}